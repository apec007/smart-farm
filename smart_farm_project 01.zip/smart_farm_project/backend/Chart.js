// สร้างกราฟสถานะสุขภาพของสัตว์
const healthData = <?php echo json_encode($health_data); ?>;
const healthLabels = healthData.map(item => item.health_status);
const healthCounts = healthData.map(item => item.count);

const healthChartCtx = document.getElementById('healthChart').getContext('2d');
new Chart(healthChartCtx, {
    type: 'pie',
    data: {
        labels: healthLabels,
        datasets: [{
            data: healthCounts,
            backgroundColor: ['#ff9999', '#66b3ff', '#99ff99', '#ffcc99'],
        }]
    }
});

// สร้างกราฟสถานะของพืชผล
const cropStatusData = <?php echo json_encode($crop_status_data); ?>;
const cropStatusLabels = cropStatusData.map(item => item.status);
const cropStatusCounts = cropStatusData.map(item => item.count);

const cropStatusChartCtx = document.getElementById('cropStatusChart').getContext('2d');
new Chart(cropStatusChartCtx, {
    type: 'bar',
    data: {
        labels: cropStatusLabels,
        datasets: [{
            label: 'จำนวนพืชผล',
            data: cropStatusCounts,
            backgroundColor: '#6fa3ef',
            borderColor: '#4a90e2',
            borderWidth: 1
        }]
    }
});

// สร้างกราฟสถานะการทำงานของเซ็นเซอร์
const sensorStatusData = <?php echo json_encode($sensor_status_data); ?>;
const sensorStatusLabels = sensorStatusData.map(item => item.status);
const sensorStatusCounts = sensorStatusData.map(item => item.count);

const sensorStatusChartCtx = document.getElementById('sensorStatusChart').getContext('2d');
new Chart(sensorStatusChartCtx, {
    type: 'pie',
    data: {
        labels: sensorStatusLabels,
        datasets: [{
            data: sensorStatusCounts,
            backgroundColor: ['#66b3ff', '#ffcc99'],
        }]
    }
});
