<?php
include('config.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$content_id = $_GET['id'];  // รับค่าหมายเลขเนื้อหาจาก URL

$sql = "DELETE FROM content WHERE id='$content_id'";
if ($conn->query($sql) === TRUE) {
    echo "เนื้อหาถูกลบสำเร็จ";
    header("Location: manage_content.php");
} else {
    echo "เกิดข้อผิดพลาดในการลบเนื้อหา";
}
?>
