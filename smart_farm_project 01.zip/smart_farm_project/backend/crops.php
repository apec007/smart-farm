<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require 'config.php';

// ดึงข้อมูลพืชผล
$stmt = $conn->prepare("SELECT * FROM crops");
$stmt->execute();
$crops = $stmt->fetchAll();

// ดึงข้อมูลเซ็นเซอร์
$stmt = $conn->prepare("SELECT * FROM sensors");
$stmt->execute();
$sensors = $stmt->fetchAll();

// ดึงข้อมูลเซ็นเซอร์ที่เชื่อมโยงกับพืชผล
$crop_sensors = [];
$stmt = $conn->prepare("SELECT * FROM crop_sensors");
$stmt->execute();
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $crop_sensors[$row['crop_id']][] = $row['sensor_id'];
}

// การลบพืชผล
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $stmt = $conn->prepare("DELETE FROM crops WHERE crop_id = ?");
    $stmt->execute([$delete_id]);
    header("Location: crops.php");
    exit();
}

// การเพิ่มเซ็นเซอร์ให้กับพืชผล
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_sensor'])) {
    $crop_id = $_POST['crop_id'];
    $sensor_id = $_POST['sensor_id'];

    $stmt = $conn->prepare("INSERT INTO crop_sensors (crop_id, sensor_id) VALUES (?, ?)");
    $stmt->execute([$crop_id, $sensor_id]);
    header("Location: crops.php");
    exit();
}

// การลบเซ็นเซอร์จากพืชผล
if (isset($_GET['remove_sensor'])) {
    $crop_sensor_id = $_GET['remove_sensor'];
    $stmt = $conn->prepare("DELETE FROM crop_sensors WHERE crop_sensor_id = ?");
    $stmt->execute([$crop_sensor_id]);
    header("Location: crops.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>พืชผล - ฟาร์มอัจฉริยะ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <?php include 'navbar.php'; ?>

    <div class="container py-5">
        <h1 class="text-center">พืชผล</h1>

        <!-- ปุ่มเพิ่มพืชผลใหม่ -->
        <div class="mb-3 text-end">
            <a href="add_crop.php" class="btn btn-success">+ เพิ่มพืชผลใหม่</a>
        </div>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>ชื่อพืช</th>
                    <th>ประเภท</th>
                    <th>วันที่ปลูก</th>
                    <th>วันที่เก็บเกี่ยว</th>
                    <th>สถานะ</th>
                    <th>เซ็นเซอร์</th>
                    <th>การจัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($crops as $crop): ?>
                    <tr>
                        <td><?php echo $crop['crop_id']; ?></td>
                        <td><?php echo $crop['name']; ?></td>
                        <td><?php echo $crop['type']; ?></td>
                        <td><?php echo $crop['planting_date']; ?></td>
                        <td><?php echo $crop['harvest_date']; ?></td>
                        <td><?php echo $crop['status']; ?></td>
                        <td>
                            <!-- แสดงเซ็นเซอร์ที่เชื่อมโยงกับพืชผล -->
                            <?php if (!empty($crop_sensors[$crop['crop_id']])): ?>
                                <ul>
                                    <?php foreach ($crop_sensors[$crop['crop_id']] as $sensor_id): ?>
                                        <?php
                                        $stmt = $conn->prepare("SELECT name FROM sensors WHERE sensor_id = ?");
                                        $stmt->execute([$sensor_id]);
                                        $sensor = $stmt->fetch(PDO::FETCH_ASSOC);
                                        ?>
                                        <li>
                                            <?php echo $sensor['name']; ?>
                                            <a href="crops.php?remove_sensor=<?php echo $sensor_id; ?>" class="btn btn-sm btn-danger" onclick="return confirm('คุณต้องการลบเซ็นเซอร์นี้ใช่หรือไม่?');">ลบ</a>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <p>ไม่มีเซ็นเซอร์</p>
                            <?php endif; ?>

                            <!-- ฟอร์มเพิ่มเซ็นเซอร์ -->
                            <form action="crops.php" method="POST" class="mt-2">
                                <input type="hidden" name="crop_id" value="<?php echo $crop['crop_id']; ?>">
                                <select name="sensor_id" class="form-select">
                                    <?php foreach ($sensors as $sensor): ?>
                                        <option value="<?php echo $sensor['sensor_id']; ?>"><?php echo $sensor['name']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="submit" name="add_sensor" class="btn btn-success mt-2">เพิ่มเซ็นเซอร์</button>
                            </form>
                        </td>
                        <td>
                            <!-- ปุ่มลบพืชผล -->
                            <a href="crops.php?delete_id=<?php echo $crop['crop_id']; ?>" class="btn btn-danger" onclick="return confirm('คุณต้องการลบข้อมูลนี้ใช่หรือไม่?');">ลบ</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>