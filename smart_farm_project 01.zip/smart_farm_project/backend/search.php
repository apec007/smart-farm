<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require 'config.php';

$results = [];
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['keyword'])) {
    $keyword = $_GET['keyword'];

    // ค้นหาในตารางสัตว์ (animals)
    $stmt = $conn->prepare("SELECT * FROM animals WHERE name LIKE :keyword OR species LIKE :keyword OR health_status LIKE :keyword");
    $stmt->execute([':keyword' => "%$keyword%"]);
    $results['animals'] = $stmt->fetchAll();

    // ค้นหาในตารางพืชผล (crops)
    $stmt = $conn->prepare("SELECT * FROM crops WHERE name LIKE :keyword OR type LIKE :keyword OR status LIKE :keyword");
    $stmt->execute([':keyword' => "%$keyword%"]);
    $results['crops'] = $stmt->fetchAll();

    // ค้นหาในตารางเซ็นเซอร์ (sensors)
    $stmt = $conn->prepare("SELECT * FROM sensors WHERE name LIKE :keyword OR type LIKE :keyword OR status LIKE :keyword");
    $stmt->execute([':keyword' => "%$keyword%"]);
    $results['sensors'] = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ผลการค้นหา - ฟาร์มอัจฉริยะ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Prompt', sans-serif;
        }
        .container {
            padding-top: 20px;
        }
        .search-form {
            margin-bottom: 20px;
        }
        .table {
            margin-top: 20px;
        }
        .no-results {
            text-align: center;
            color: #6c757d;
            margin-top: 20px;
        }
    </style>
</head>
<body class="bg-light">
    <?php include 'navbar.php'; ?>

    <div class="container">
        <h1 class="text-center">ผลการค้นหา</h1>
        <form method="GET" action="" class="search-form">
            <div class="input-group mb-3">
                <input type="text" class="form-control" name="keyword" placeholder="ค้นหา..." required>
                <button type="submit" class="btn btn-primary">ค้นหา</button>
            </div>
        </form>

        <?php if (!empty($results)): ?>
            <!-- ผลการค้นหาสัตว์ -->
            <?php if (!empty($results['animals'])): ?>
                <h3>สัตว์</h3>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>ชื่อ</th>
                            <th>สายพันธุ์</th>
                            <th>วันเกิด</th>
                            <th>สถานะสุขภาพ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($results['animals'] as $animal): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($animal['animal_id']); ?></td>
                                <td><?php echo htmlspecialchars($animal['name']); ?></td>
                                <td><?php echo htmlspecialchars($animal['species']); ?></td>
                                <td><?php echo htmlspecialchars($animal['birth_date']); ?></td>
                                <td><?php echo htmlspecialchars($animal['health_status']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <!-- ผลการค้นหาพืชผล -->
            <?php if (!empty($results['crops'])): ?>
                <h3>พืชผล</h3>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>ชื่อพืช</th>
                            <th>ประเภท</th>
                            <th>วันที่ปลูก</th>
                            <th>วันที่เก็บเกี่ยว</th>
                            <th>สถานะ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($results['crops'] as $crop): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($crop['crop_id']); ?></td>
                                <td><?php echo htmlspecialchars($crop['name']); ?></td>
                                <td><?php echo htmlspecialchars($crop['type']); ?></td>
                                <td><?php echo htmlspecialchars($crop['planting_date']); ?></td>
                                <td><?php echo htmlspecialchars($crop['harvest_date']); ?></td>
                                <td><?php echo htmlspecialchars($crop['status']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <!-- ผลการค้นหาเซ็นเซอร์ -->
            <?php if (!empty($results['sensors'])): ?>
                <h3>เซ็นเซอร์</h3>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>ชื่อเซ็นเซอร์</th>
                            <th>ประเภท</th>
                            <th>สถานะ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($results['sensors'] as $sensor): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($sensor['sensor_id']); ?></td>
                                <td><?php echo htmlspecialchars($sensor['name']); ?></td>
                                <td><?php echo htmlspecialchars($sensor['type']); ?></td>
                                <td><?php echo htmlspecialchars($sensor['status']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        <?php else: ?>
            <p class="no-results">ไม่พบผลลัพธ์</p>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>