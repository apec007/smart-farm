<?php
include('config.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$content_id = $_GET['id'];  // รับค่าหมายเลขเนื้อหาจาก URL
$sql = "SELECT * FROM content WHERE id='$content_id'";
$result = $conn->query($sql);
$content = $result->fetch_assoc();

if (isset($_POST['update_content'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];

    $sql = "UPDATE content SET title='$title', description='$description' WHERE id='$content_id'";
    if ($conn->query($sql) === TRUE) {
        echo "เนื้อหาถูกอัปเดตสำเร็จ";
        header("Location: manage_content.php");
    } else {
        echo "เกิดข้อผิดพลาด: " . $conn->error;
    }
}
?>

<form method="post" action="edit_content.php?id=<?php echo $content['id']; ?>">
    <label for="title">หัวข้อ:</label>
    <input type="text" id="title" name="title" value="<?php echo $content['title']; ?>" required>
    <label for="description">คำอธิบาย:</label>
    <textarea id="description" name="description" required><?php echo $content['description']; ?></textarea>
    <button type="submit" name="update_content">อัปเดตเนื้อหา</button>
</form>
