<?php
include('config.php');
session_start();

$keyword = '';
$category = '';

if (isset($_GET['search'])) {
    $keyword = $_GET['search'];
}
if (isset($_GET['category'])) {
    $category = $_GET['category'];
}

$sql = "SELECT * FROM content WHERE title LIKE '%$keyword%' OR description LIKE '%$keyword%'";

if ($category != '') {
    $sql .= " AND category='$category'";
}

$result = $conn->query($sql);
?>

<form method="get" action="search_filter.php">
    <label for="search">ค้นหาข้อมูล:</label>
    <input type="text" id="search" name="search" value="<?php echo $keyword; ?>">
    
    <label for="category">เลือกหมวดหมู่:</label>
    <select id="category" name="category">
        <option value="">เลือกหมวดหมู่</option>
        <option value="พืช" <?php if ($category == 'พืช') echo 'selected'; ?>>พืช</option>
        <option value="สัตว์" <?php if ($category == 'สัตว์') echo 'selected'; ?>>สัตว์</option>
        <option value="เทคโนโลยี" <?php if ($category == 'เทคโนโลยี') echo 'selected'; ?>>เทคโนโลยี</option>
    </select>

    <button type="submit">ค้นหาและกรอง</button>
</form>

<h2>ผลการค้นหาและกรองข้อมูล</h2>
<?php
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div><h3>" . $row['title'] . "</h3><p>" . $row['description'] . "</p></div>";
    }
} else {
    echo "ไม่พบข้อมูลที่ตรงกับคำค้นหาและเงื่อนไข";
}
?>
