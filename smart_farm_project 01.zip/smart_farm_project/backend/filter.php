<?php
include('config.php');
session_start();

$category = '';
if (isset($_GET['category'])) {
    $category = $_GET['category'];
    $sql = "SELECT * FROM content WHERE category='$category'";
} else {
    $sql = "SELECT * FROM content";
}

$result = $conn->query($sql);
?>

<form method="get" action="filter.php">
    <label for="category">เลือกหมวดหมู่:</label>
    <select id="category" name="category">
        <option value="พืช">พืช</option>
        <option value="สัตว์">สัตว์</option>
        <option value="เทคโนโลยี">เทคโนโลยี</option>
    </select>
    <button type="submit">กรอง</button>
</form>

<h2>ผลการกรองข้อมูล</h2>
<?php
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div><h3>" . $row['title'] . "</h3><p>" . $row['description'] . "</p></div>";
    }
} else {
    echo "ไม่พบข้อมูลที่ตรงกับเงื่อนไข";
}
?>
