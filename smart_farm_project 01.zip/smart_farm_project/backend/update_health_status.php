<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require 'config.php';

if (isset($_POST['animal_id']) && isset($_POST['health_status'])) {
    $animal_id = $_POST['animal_id'];
    $health_status = $_POST['health_status'];

    // อัปเดตสถานะสุขภาพของสัตว์ในฐานข้อมูล
    $stmt = $conn->prepare("UPDATE animals SET health_status = ? WHERE animal_id = ?");
    $stmt->execute([$health_status, $animal_id]);

    // Redirect กลับไปที่หน้าหลักของสัตว์
    header("Location: animals.php");
    exit();
}
?>
