<?php
include('config.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $type = $_POST['type']; // ประเภท เช่น พืช, สัตว์, เซ็นเซอร์

    // SQL Query สำหรับการเพิ่มเนื้อหา
    $sql = "INSERT INTO crops (name, type, description) VALUES ('$name', '$type', '$description')";

    if ($conn->query($sql) === TRUE) {
        echo "เพิ่มข้อมูลสำเร็จ!";
    } else {
        echo "เกิดข้อผิดพลาด: " . $conn->error;
    }
}
?>

<form method="POST" action="create_content.php">
    <input type="text" name="name" placeholder="ชื่อเนื้อหา" required><br>
    <textarea name="description" placeholder="รายละเอียดเนื้อหา"></textarea><br>
    <select name="type">
        <option value="crop">พืช</option>
        <option value="animal">สัตว์</option>
        <option value="sensor">เซ็นเซอร์</option>
    </select><br>
    <button type="submit">เพิ่มเนื้อหา</button>
</form>
