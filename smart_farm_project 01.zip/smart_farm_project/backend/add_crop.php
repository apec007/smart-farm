<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require 'config.php';

// การเพิ่มข้อมูลพืชผล
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $type = $_POST['type'];
    $planting_date = $_POST['planting_date'];
    $harvest_date = $_POST['harvest_date'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("INSERT INTO crops (name, type, planting_date, harvest_date, status) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$name, $type, $planting_date, $harvest_date, $status]);

    header("Location: crops.php"); // เมื่อบันทึกเสร็จแล้วให้กลับไปที่หน้ารายการพืชผล
    exit();
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เพิ่มพืชผล - ฟาร์มอัจฉริยะ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <?php include 'navbar.php'; ?>

    <div class="container py-5">
        <h1 class="text-center">เพิ่มพืชผลใหม่</h1>

        <form method="POST">
            <div class="mb-3">
                <label for="name" class="form-label">ชื่อพืช</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="mb-3">
                <label for="type" class="form-label">ประเภท</label>
                <input type="text" class="form-control" id="type" name="type" required>
            </div>
            <div class="mb-3">
                <label for="planting_date" class="form-label">วันที่ปลูก</label>
                <input type="date" class="form-control" id="planting_date" name="planting_date" required>
            </div>
            <div class="mb-3">
                <label for="harvest_date" class="form-label">วันที่เก็บเกี่ยว</label>
                <input type="date" class="form-control" id="harvest_date" name="harvest_date" required>
            </div>
            <div class="mb-3">
                <label for="status" class="form-label">สถานะ</label>
                <input type="text" class="form-control" id="status" name="status" required>
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-success">บันทึกข้อมูล</button>
            </div>
        </form>
    </div>
</body>
</html>
