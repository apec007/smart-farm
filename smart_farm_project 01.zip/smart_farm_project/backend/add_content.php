<?php
include('config.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (isset($_POST['add_content'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];

    $sql = "INSERT INTO content (title, description) VALUES ('$title', '$description')";
    if ($conn->query($sql) === TRUE) {
        echo "เนื้อหาถูกเพิ่มสำเร็จ";
        header("Location: manage_content.php");
    } else {
        echo "เกิดข้อผิดพลาด: " . $conn->error;
    }
}
?>

<form method="post" action="add_content.php">
    <label for="title">หัวข้อ:</label>
    <input type="text" id="title" name="title" required>
    <label for="description">คำอธิบาย:</label>
    <textarea id="description" name="description" required></textarea>
    <button type="submit" name="add_content">เพิ่มเนื้อหา</button>
</form>
