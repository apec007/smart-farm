<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $species = $_POST['species'];
    $birth_date = $_POST['birth_date'];
    $health_status = $_POST['health_status'];

    // การเพิ่มข้อมูลสัตว์ใหม่ลงในฐานข้อมูล
    $stmt = $conn->prepare("INSERT INTO animals (name, species, birth_date, health_status) VALUES (?, ?, ?, ?)");
    $stmt->execute([$name, $species, $birth_date, $health_status]);

    header("Location: animals.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เพิ่มสัตว์ - ฟาร์มอัจฉริยะ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <?php include 'navbar.php'; ?>

    <div class="container py-5">
        <h1 class="text-center">เพิ่มสัตว์ใหม่</h1>

        <form action="add_animal.php" method="POST">
            <div class="mb-3">
                <label for="name" class="form-label">ชื่อสัตว์</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>

            <div class="mb-3">
                <label for="species" class="form-label">พันธุ์</label>
                <select class="form-select" id="species" name="species" required>
                    <option value="วัว">วัว</option>
                    <option value="ควาย">ควาย</option>
                    <option value="หมู">หมู</option>
                    <option value="ไก่">ไก่</option>
                    <option value="เป็ด">เป็ด</option>
                    <option value="แพะ">แพะ</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="birth_date" class="form-label">วันเกิด</label>
                <input type="date" class="form-control" id="birth_date" name="birth_date" required>
            </div>

            <div class="mb-3">
                <label for="health_status" class="form-label">สถานะสุขภาพ</label>
                <select class="form-select" id="health_status" name="health_status" required>
                    <option value="แข็งแรง">แข็งแรง</option>
                    <option value="ป่วย">ป่วย</option>
                    <option value="กำลังรักษา">กำลังรักษา</option>
                </select>
            </div>

            <button type="submit" class="btn btn-success">บันทึกสัตว์ใหม่</button>
        </form>
    </div>
</body>
</html>
