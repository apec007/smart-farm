<?php
session_start();
require 'config.php';
require 'vendor/autoload.php';

use League\OAuth2\Client\Provider\Twitter;

$twitterProvider = new Twitter([
    'clientId'     => 'YOUR_TWITTER_CLIENT_ID',
    'clientSecret' => 'YOUR_TWITTER_CLIENT_SECRET',
    'redirectUri'  => 'http://yourwebsite.com/twitter-callback.php',
]);

if (!isset($_GET['oauth_token'])) {
    header('Location: login.php');
    exit();
}

$token = $twitterProvider->getAccessToken('authorization_code', [
    'oauth_token' => $_GET['oauth_token'],
    'oauth_verifier' => $_GET['oauth_verifier'],
]);

$user = $twitterProvider->getResourceOwner($token);

$_SESSION['user_id'] = $user->getId();
$_SESSION['name'] = $user->getName();
$_SESSION['email'] = $user->getEmail();

header('Location: profile.php');
exit();
