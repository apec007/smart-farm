<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ฟาร์มอัจฉริยะ</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome สำหรับไอคอน -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- CSS สำหรับการแจ้งเตือน -->
    <style>
        #sensorAlert {
            position: relative;
        }
        #alertBadge {
            position: absolute;
            top: 0;
            right: 0;
            font-size: 12px;
            padding: 5px;
            border-radius: 50%;
        }
        .alert-message {
            display: none;
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">ฟาร์มอัจฉริยะ</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">แดชบอร์ด</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="animals.php">สัตว์</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="crops.php">พืชผล</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="sensors.php">เซ็นเซอร์</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="search.php">ค้นหา</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">โปรไฟล์</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact_admin.php">ติดต่อแอดมิน</a>
                    </li>
                    <!-- เพิ่มไอคอนการแจ้งเตือน -->
                    <li class="nav-item">
                        <a class="nav-link" href="#" id="sensorAlert">
                            <i class="fas fa-exclamation-triangle"></i>
                            <span class="badge bg-danger" id="alertBadge" style="display: none;">!</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">ออกจากระบบ</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- แจ้งเตือนแบบ Pop-up -->
    <div class="alert alert-danger alert-message" id="sensorAlertMessage">
        <strong>คำเตือน!</strong> เซ็นเซอร์ทำงานผิดปกติ
    </div>

    <!-- Bootstrap JS และ dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    <!-- JavaScript สำหรับตรวจสอบสถานะเซ็นเซอร์ -->
    <script>
        // ฟังก์ชันแสดงการแจ้งเตือน
        function showAlert() {
            // แสดง Badge บน Navbar
            document.getElementById('alertBadge').style.display = 'inline-block';
            // แสดง Pop-up แจ้งเตือน
            document.getElementById('sensorAlertMessage').style.display = 'block';
            // ซ่อน Pop-up หลังจาก 5 วินาที
            setTimeout(() => {
                document.getElementById('sensorAlertMessage').style.display = 'none';
            }, 5000);
        }

        // ฟังก์ชันตรวจสอบสถานะเซ็นเซอร์
        function checkSensorStatus() {
            // เรียก API เพื่อตรวจสอบสถานะเซ็นเซอร์
            fetch('check_sensor_status.php')
                .then(response => response.json())
                .then(data => {
                    if (data.hasIssue) {
                        // แสดงการแจ้งเตือนหากเซ็นเซอร์มีปัญหา
                        showAlert();
                    } else {
                        // ซ่อน Badge หากเซ็นเซอร์ปกติ
                        document.getElementById('alertBadge').style.display = 'none';
                    }
                })
                .catch(error => console.error('Error:', error));
        }

        // ตรวจสอบสถานะเซ็นเซอร์ทุก 1 นาที
        setInterval(checkSensorStatus, 60000);

        // ตรวจสอบสถานะเซ็นเซอร์เมื่อโหลดหน้า
        window.onload = checkSensorStatus;
    </script>
</body>
</html>