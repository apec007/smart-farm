<?php
// check_sensor_status.php
header('Content-Type: application/json');

// เชื่อมต่อฐานข้อมูล
$host = 'localhost';
$dbname = 'smart_farm_db';
$username = 'root'; // เปลี่ยนเป็น username ของคุณ
$password = ''; // เปลี่ยนเป็น password ของคุณ

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die(json_encode(['hasIssue' => false, 'error' => 'Connection failed: ' . $e->getMessage()]));
}

// ตรวจสอบสถานะเซ็นเซอร์
$query = "SELECT COUNT(*) as issue_count FROM sensors WHERE status = 'ผิดปกติ'";
$stmt = $conn->prepare($query);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);

$sensorStatus = [
    'hasIssue' => ($result['issue_count'] > 0) // มีเซ็นเซอร์ผิดปกติหรือไม่
];

echo json_encode($sensorStatus);
?>