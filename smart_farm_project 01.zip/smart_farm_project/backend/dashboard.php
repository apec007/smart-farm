<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require 'config.php';

// ดึงข้อมูลจำนวนสัตว์
$stmt = $conn->prepare("SELECT COUNT(*) AS animal_count FROM animals");
$stmt->execute();
$animal_count = $stmt->fetch(PDO::FETCH_ASSOC)['animal_count'];

// ดึงข้อมูลจำนวนพืชผล
$stmt = $conn->prepare("SELECT COUNT(*) AS crop_count FROM crops");
$stmt->execute();
$crop_count = $stmt->fetch(PDO::FETCH_ASSOC)['crop_count'];

// ดึงข้อมูลจำนวนเซ็นเซอร์
$stmt = $conn->prepare("SELECT COUNT(*) AS sensor_count FROM sensors");
$stmt->execute();
$sensor_count = $stmt->fetch(PDO::FETCH_ASSOC)['sensor_count'];

// ดึงข้อมูลจำนวนสัตว์ตามสถานะสุขภาพ
$stmt = $conn->prepare("SELECT health_status, COUNT(*) AS count FROM animals GROUP BY health_status");
$stmt->execute();
$health_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ดึงข้อมูลจำนวนพืชผลตามสถานะ
$stmt = $conn->prepare("SELECT status, COUNT(*) AS count FROM crops GROUP BY status");
$stmt->execute();
$crop_status_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ดึงข้อมูลสถานะการทำงานของเซ็นเซอร์
$stmt = $conn->prepare("SELECT status, COUNT(*) AS count FROM sensors GROUP BY status");
$stmt->execute();
$sensor_status_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>แดชบอร์ด - ฟาร์มอัจฉริยะ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-light">
    <?php include 'navbar.php'; ?>

    <div class="container py-5">
        <h1 class="text-center">ยินดีต้อนรับสู่แดชบอร์ด!</h1>
        
        <!-- สรุปค่าสถิติ -->
        <div class="row mt-4">
            <div class="col-md-4">
                <div class="card shadow">
                    <div class="card-body">
                        <h5 class="card-title">จำนวนสัตว์</h5>
                        <p class="card-text"><?php echo $animal_count; ?> ตัว</p>
                        <a href="animals.php" class="btn btn-primary">ดูสัตว์</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow">
                    <div class="card-body">
                        <h5 class="card-title">จำนวนพืชผล</h5>
                        <p class="card-text"><?php echo $crop_count; ?> ชนิด</p>
                        <a href="crops.php" class="btn btn-primary">ดูพืชผล</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow">
                    <div class="card-body">
                        <h5 class="card-title">จำนวนเซ็นเซอร์</h5>
                        <p class="card-text"><?php echo $sensor_count; ?> ตัว</p>
                        <a href="sensors.php" class="btn btn-primary">ดูเซ็นเซอร์</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- กราฟแสดงสถานะสุขภาพของสัตว์ -->
        <div class="row mt-5">
            <div class="col-md-6">
                <h4>สถานะสุขภาพของสัตว์</h4>
                <canvas id="healthChart"></canvas>
            </div>
            <!-- กราฟแสดงสถานะของพืชผล -->
            <div class="col-md-6">
                <h4>สถานะของพืชผล</h4>
                <canvas id="cropStatusChart"></canvas>
            </div>
        </div>

        <!-- กราฟแสดงสถานะการทำงานของเซ็นเซอร์ -->
        <div class="row mt-5">
            <div class="col-md-6">
                <h4>สถานะการทำงานของเซ็นเซอร์</h4>
                <canvas id="sensorStatusChart"></canvas>
            </div>
        </div>
    </div>

    <script>
        // สร้างกราฟสถานะสุขภาพของสัตว์
        const healthData = <?php echo json_encode($health_data); ?>;
        const healthLabels = healthData.map(item => item.health_status);
        const healthCounts = healthData.map(item => item.count);

        const healthChartCtx = document.getElementById('healthChart').getContext('2d');
        new Chart(healthChartCtx, {
            type: 'pie',
            data: {
                labels: healthLabels,
                datasets: [{
                    data: healthCounts,
                    backgroundColor: ['#ff9999', '#66b3ff', '#99ff99', '#ffcc99'],
                }]
            }
        });

        // สร้างกราฟสถานะของพืชผล
        const cropStatusData = <?php echo json_encode($crop_status_data); ?>;
        const cropStatusLabels = cropStatusData.map(item => item.status);
        const cropStatusCounts = cropStatusData.map(item => item.count);

        const cropStatusChartCtx = document.getElementById('cropStatusChart').getContext('2d');
        new Chart(cropStatusChartCtx, {
            type: 'bar',
            data: {
                labels: cropStatusLabels,
                datasets: [{
                    label: 'จำนวนพืชผล',
                    data: cropStatusCounts,
                    backgroundColor: '#6fa3ef',
                    borderColor: '#4a90e2',
                    borderWidth: 1
                }]
            }
        });

        // สร้างกราฟสถานะการทำงานของเซ็นเซอร์
        const sensorStatusData = <?php echo json_encode($sensor_status_data); ?>;
        const sensorStatusLabels = sensorStatusData.map(item => item.status);
        const sensorStatusCounts = sensorStatusData.map(item => item.count);

        const sensorStatusChartCtx = document.getElementById('sensorStatusChart').getContext('2d');
        new Chart(sensorStatusChartCtx, {
            type: 'pie',
            data: {
                labels: sensorStatusLabels,
                datasets: [{
                    data: sensorStatusCounts,
                    backgroundColor: ['#66b3ff', '#ffcc99'],
                }]
            }
        });
    </script>
</body>
</html>
