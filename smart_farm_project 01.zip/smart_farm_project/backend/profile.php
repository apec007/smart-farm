<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require 'config.php';

$user_id = $_SESSION['user_id'];

// ตรวจสอบว่ามีข้อมูลใน user_profiles หรือไม่
$stmt = $conn->prepare("SELECT * FROM user_profiles WHERE user_id = ?");
$stmt->execute([$user_id]);
$profile = $stmt->fetch();

if (!$profile) {
    // ถ้ายังไม่มีข้อมูลโปรไฟล์ ให้เพิ่มข้อมูลเริ่มต้น
    $stmt = $conn->prepare("INSERT INTO user_profiles (user_id, full_name, phone, address, avatar) VALUES (?, '', '', '', NULL)");
    $stmt->execute([$user_id]);

    // ดึงข้อมูลใหม่อีกครั้ง
    $stmt = $conn->prepare("SELECT * FROM user_profiles WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $profile = $stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = $_POST['full_name'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];

    // อัปเดตข้อมูลโปรไฟล์
    $stmt = $conn->prepare("UPDATE user_profiles SET full_name = ?, phone = ?, address = ? WHERE user_id = ?");
    $stmt->execute([$full_name, $phone, $address, $user_id]);

    // อัปโหลดรูปภาพโปรไฟล์
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] == 0) {
        $target_dir = "uploads/"; // โฟลเดอร์สำหรับเก็บรูปภาพ
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0755, true); // สร้างโฟลเดอร์ถ้ายังไม่มี
        }

        $file_name = basename($_FILES['avatar']['name']);
        $target_file = $target_dir . uniqid() . "_" . $file_name; // เพิ่ม unique ID เพื่อป้องกันชื่อไฟล์ซ้ำ
        $image_file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // ตรวจสอบประเภทไฟล์
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($image_file_type, $allowed_types)) {
            if (move_uploaded_file($_FILES['avatar']['tmp_name'], $target_file)) {
                // อัปเดต URL รูปภาพในฐานข้อมูล
                $stmt = $conn->prepare("UPDATE user_profiles SET avatar = ? WHERE user_id = ?");
                $stmt->execute([$target_file, $user_id]);
                $profile['avatar'] = $target_file; // อัปเดตข้อมูลในตัวแปร $profile
            } else {
                echo "<div class='alert alert-danger'>เกิดข้อผิดพลาดในการอัปโหลดไฟล์</div>";
            }
        } else {
            echo "<div class='alert alert-danger'>อนุญาตเฉพาะไฟล์ JPG, JPEG, PNG, และ GIF เท่านั้น</div>";
        }
    }

    echo "<div class='alert alert-success'>อัปเดตข้อมูลโปรไฟล์เรียบร้อยแล้ว!</div>";
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>โปรไฟล์ - ฟาร์มอัจฉริยะ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .avatar-preview {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #007bff;
            margin-bottom: 20px;
        }
        .form-label {
            font-weight: bold;
        }
    </style>
</head>
<body class="bg-light">
    <?php include 'navbar.php'; ?>

    <div class="container py-5">
        <h1 class="text-center">การจัดการโปรไฟล์</h1>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <!-- แสดงรูปภาพโปรไฟล์ -->
                <div class="text-center">
                    <?php if (!empty($profile['avatar'])): ?>
                        <img src="<?php echo htmlspecialchars($profile['avatar']); ?>" alt="รูปภาพโปรไฟล์" class="avatar-preview">
                    <?php else: ?>
                        <img src="https://via.placeholder.com/150" alt="รูปภาพโปรไฟล์" class="avatar-preview">
                    <?php endif; ?>
                </div>

                <!-- ฟอร์มอัปเดตโปรไฟล์ -->
                <form method="POST" action="" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="full_name" class="form-label">ชื่อเต็ม</label>
                        <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo htmlspecialchars($profile['full_name']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="phone" class="form-label">เบอร์โทรศัพท์</label>
                        <input type="text" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($profile['phone']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="address" class="form-label">ที่อยู่</label>
                        <textarea class="form-control" id="address" name="address" required><?php echo htmlspecialchars($profile['address']); ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="avatar" class="form-label">รูปภาพโปรไฟล์</label>
                        <input type="file" class="form-control" id="avatar" name="avatar" accept="image/*">
                    </div>
                    <button type="submit" class="btn btn-primary">อัปเดตโปรไฟล์</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>