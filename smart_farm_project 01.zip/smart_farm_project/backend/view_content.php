<?php
include('config.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
}

$sql = "SELECT * FROM crops";
$result = $conn->query($sql);

echo "<h1>รายการเนื้อหา</h1>";
echo "<table>";
echo "<tr><th>ชื่อเนื้อหา</th><th>ประเภท</th><th>รายละเอียด</th><th>แก้ไข</th><th>ลบ</th></tr>";
while ($row = $result->fetch_assoc()) {
    echo "<tr>
            <td>" . $row['name'] . "</td>
            <td>" . $row['type'] . "</td>
            <td>" . $row['description'] . "</td>
            <td><a href='edit_content.php?id=" . $row['crop_id'] . "'>แก้ไข</a></td>
            <td><a href='delete_content.php?id=" . $row['crop_id'] . "'>ลบ</a></td>
          </tr>";
}
echo "</table>";
?>
