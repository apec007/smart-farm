# Smart Farm System

## Installation
1. Clone the repository: `git clone https://github.com/your-repo/smart-farm.git`
2. Import the database: `smart_farm_db.sql`
3. Configure the database connection in `backend/config.php`
4. Run the application: `http://localhost/smart-farm`

## Features
- User Management (Registration, Login, Logout, Profile Management, Password Recovery)
- Content Management (CRUD Operations, File Upload)
- Search and Filter (Keyword Search, Filtering)
- Reporting and Analytics (Report Generation, Charts and Graphs)
- Security (Authentication, Authorization)