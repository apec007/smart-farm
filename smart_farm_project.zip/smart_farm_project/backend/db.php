<?php
$servername = "localhost";  // ที่อยู่เซิร์ฟเวอร์ฐานข้อมูล
$username = "root";         // ชื่อผู้ใช้ MySQL (ค่าเริ่มต้นใน XAMPP คือ "root")
$password = "";             // รหัสผ่าน MySQL (ค่าเริ่มต้นใน XAMPP คือไม่มีรหัสผ่าน)
$dbname = "smart_farm_db";  // ชื่อฐานข้อมูลที่คุณต้องการเชื่อมต่อ

// เชื่อมต่อฐานข้อมูล
$conn = mysqli_connect($servername, $username, $password, $dbname);

// ตรวจสอบการเชื่อมต่อ
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
