<?php
include('config.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$sql = "SELECT MONTH(created_at) AS month, COUNT(*) AS count FROM users GROUP BY MONTH(created_at)";
$result = $conn->query($sql);

// เตรียมข้อมูลเพื่อสร้างกราฟ
$months = [];
$growth = [];
while ($row = $result->fetch_assoc()) {
    $months[] = $row['month'];
    $growth[] = $row['count'];
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>การเติบโตของผู้ใช้</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <h2>การเติบโตของผู้ใช้ในแต่ละเดือน</h2>
    <canvas id="growthChart" width="400" height="200"></canvas>

    <script>
        var ctx = document.getElementById('growthChart').getContext('2d');
        var growthChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($months); ?>, // เดือน
                datasets: [{
                    label: 'จำนวนผู้ใช้ในแต่ละเดือน',
                    data: <?php echo json_encode($growth); ?>, // จำนวนผู้ใช้
                    fill: false,
                    borderColor: 'rgba(75, 192, 192, 1)',
                    tension: 0.1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
