<?php
include('config.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    // ตรวจสอบว่ามีอีเมลในระบบหรือไม่
    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $token = bin2hex(random_bytes(50));
        $sql = "UPDATE users SET password_reset_token='$token' WHERE email='$email'";
        if ($conn->query($sql) === TRUE) {
            // ส่งลิงก์ไปยังอีเมล (ตัวอย่างไม่ส่งจริง)
            echo "ส่งลิงก์กู้คืนรหัสผ่านไปยังอีเมลของคุณแล้ว!";
        }
    } else {
        echo "ไม่พบอีเมลนี้ในระบบ!";
    }
}
?>

<form method="POST" action="forgot_password.php">
    <input type="email" name="email" placeholder="Enter your email" required><br>
    <button type="submit">กู้คืนรหัสผ่าน</button>
</form>
