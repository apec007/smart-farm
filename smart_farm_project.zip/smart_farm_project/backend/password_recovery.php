<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user) {
        $new_password = bin2hex(random_bytes(8));
        $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
        $stmt->execute([$hashed_password, $email]);

        // ส่งอีเมลที่มีรหัสผ่านใหม่
        mail($email, "การฟื้นฟูรหัสผ่าน", "รหัสผ่านใหม่ของคุณคือ: $new_password");

        echo "รหัสผ่านใหม่ได้ถูกส่งไปยังอีเมลของคุณแล้ว";
    } else {
        echo "ไม่พบอีเมลนี้!";
    }
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ฟื้นฟูรหัสผ่าน - ฟาร์มอัจฉริยะ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white text-center">
                        <h3>ฟื้นฟูรหัสผ่าน</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="email" class="form-label">อีเมล</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">ฟื้นฟูรหัสผ่าน</button>
                        </form>
                        <p class="mt-3 text-center">จำรหัสผ่านได้แล้ว? <a href="login.php">เข้าสู่ระบบที่นี่</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
