<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="dashboard.php">ฟาร์มอัจฉริยะ</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php">แดชบอร์ด</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="animals.php">สัตว์</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="crops.php">พืชผล</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="sensors.php">เซ็นเซอร์</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="search.php">ค้นหา</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">ออกจากระบบ</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
