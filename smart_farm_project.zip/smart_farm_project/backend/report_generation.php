<?php
include('config.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
}

// ดึงข้อมูลพืชจากฐานข้อมูล
$sql = "SELECT * FROM crops"; // แก้ไขชื่อฐานข้อมูลตามที่ใช้จริง
$result = $conn->query($sql);

echo "<h1>รายงานฟาร์มสมาร์ทฟาร์ม</h1>";
echo "<table border='1'>";
echo "<tr><th>ชื่อพืช</th><th>ประเภท</th><th>สถานะ</th><th>รายละเอียด</th></tr>";

while ($row = $result->fetch_assoc()) {
    echo "<tr>
            <td>" . $row['name'] . "</td>
            <td>" . $row['type'] . "</td>
            <td>" . $row['status'] . "</td>
            <td>" . $row['description'] . "</td>
          </tr>";
}

echo "</table>";
?>
