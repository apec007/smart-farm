<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require 'config.php';

// การดึงข้อมูลเซ็นเซอร์จากฐานข้อมูล
$stmt = $conn->prepare("SELECT * FROM sensors");
$stmt->execute();
$sensors = $stmt->fetchAll();

// การลบเซ็นเซอร์
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $stmt = $conn->prepare("DELETE FROM sensors WHERE sensor_id = ?");
    $stmt->execute([$delete_id]);
    header("Location: sensors.php"); // เมื่อลบเสร็จแล้วให้กลับไปที่หน้ารายการเซ็นเซอร์
    exit();
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เซ็นเซอร์ - ฟาร์มอัจฉริยะ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <?php include 'navbar.php'; ?>

    <div class="container py-5">
        <h1 class="text-center">เซ็นเซอร์</h1>

        <!-- ปุ่มเพิ่มเซ็นเซอร์ใหม่ -->
        <div class="mb-3 text-end">
            <a href="add_sensor.php" class="btn btn-success">+ เพิ่มเซ็นเซอร์ใหม่</a>
        </div>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>ชื่อเซ็นเซอร์</th>
                    <th>ประเภท</th>
                    <th>สถานะ</th>
                    <th>การจัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($sensors as $sensor): ?>
                    <tr>
                        <td><?php echo $sensor['sensor_id']; ?></td>
                        <td><?php echo $sensor['name']; ?></td>
                        <td><?php echo $sensor['type']; ?></td>
                        <td>
                            <!-- แสดงสถานะเซ็นเซอร์ -->
                            <span class="badge <?php echo ($sensor['status'] == 'ปกติ') ? 'bg-success' : 'bg-danger'; ?>">
                                <?php echo $sensor['status']; ?>
                            </span>
                        </td>
                        <td>
                            <!-- ปุ่มลบเซ็นเซอร์ -->
                            <a href="sensors.php?delete_id=<?php echo $sensor['sensor_id']; ?>" class="btn btn-danger" onclick="return confirm('คุณต้องการลบข้อมูลนี้ใช่หรือไม่?');">ลบ</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>


