<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require 'config.php';

// ดึงข้อมูลสถิติ
$stmt = $conn->prepare("SELECT COUNT(*) as total_animals FROM animals");
$stmt->execute();
$total_animals = $stmt->fetch()['total_animals'];

$stmt = $conn->prepare("SELECT COUNT(*) as total_crops FROM crops");
$stmt->execute();
$total_crops = $stmt->fetch()['total_crops'];
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>สถิติ - ฟาร์มอัจฉริยะ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <?php include 'navbar.php'; ?>

    <div class="container py-5">
        <h1 class="text-center">สถิติฟาร์ม</h1>
        <div class="row mt-4">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-body">
                        <h5 class="card-title">จำนวนสัตว์ทั้งหมด</h5>
                        <p class="card-text"><?php echo $total_animals; ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-body">
                        <h5 class="card-title">จำนวนพืชทั้งหมด</h5>
                        <p class="card-text"><?php echo $total_crops; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
