<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>สร้างรายงาน - ฟาร์มอัจฉริยะ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <?php include 'navbar.php'; ?>

    <div class="container py-5">
        <h1 class="text-center">สัตว์ที่มีสถานะป่วย</h1>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>ชื่อ</th>
                    <th>พันธุ์</th>
                    <th>วันเกิด</th>
                    <th>สถานะสุขภาพ</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($sick_animals as $animal): ?>
                    <tr>
                        <td><?php echo $animal['animal_id']; ?></td>
                        <td><?php echo $animal['name']; ?></td>
                        <td><?php echo $animal['species']; ?></td>
                        <td><?php echo $animal['birth_date']; ?></td>
                        <td><?php echo $animal['health_status']; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
