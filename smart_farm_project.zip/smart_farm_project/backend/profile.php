<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require 'config.php';

$user_id = $_SESSION['user_id'];

// ตรวจสอบว่ามีข้อมูลใน user_profiles หรือไม่
$stmt = $conn->prepare("SELECT * FROM user_profiles WHERE user_id = ?");
$stmt->execute([$user_id]);
$profile = $stmt->fetch();

if (!$profile) {
    // ถ้ายังไม่มีข้อมูลโปรไฟล์ ให้เพิ่มข้อมูลเริ่มต้น
    $stmt = $conn->prepare("INSERT INTO user_profiles (user_id, full_name, phone, address) VALUES (?, '', '', '')");
    $stmt->execute([$user_id]);

    // ดึงข้อมูลใหม่อีกครั้ง
    $stmt = $conn->prepare("SELECT * FROM user_profiles WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $profile = $stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = $_POST['full_name'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];

    $stmt = $conn->prepare("UPDATE user_profiles SET full_name = ?, phone = ?, address = ? WHERE user_id = ?");
    $stmt->execute([$full_name, $phone, $address, $user_id]);

    echo "<div class='alert alert-success'>อัปเดตข้อมูลโปรไฟล์เรียบร้อยแล้ว!</div>";
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>โปรไฟล์ - ฟาร์มอัจฉริยะ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <?php include 'navbar.php'; ?>

    <div class="container py-5">
        <h1 class="text-center">การจัดการโปรไฟล์</h1>
        <form method="POST" action="">
            <div class="mb-3">
                <label for="full_name" class="form-label">ชื่อเต็ม</label>
                <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo htmlspecialchars($profile['full_name']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="phone" class="form-label">เบอร์โทรศัพท์</label>
                <input type="text" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars($profile['phone']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="address" class="form-label">ที่อยู่</label>
                <textarea class="form-control" id="address" name="address" required><?php echo htmlspecialchars($profile['address']); ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">อัปเดตโปรไฟล์</button>
        </form>
    </div>
</body>
</html>
