<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require 'config.php';

$results = [];
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['keyword'])) {
    $keyword = $_GET['keyword'];

    // ค้นหาในตารางสัตว์
    $stmt = $conn->prepare("SELECT * FROM animals WHERE name LIKE ?");
    $stmt->execute(["%$keyword%"]);
    $results['animals'] = $stmt->fetchAll();

    // ค้นหาในตารางพืชผล
    $stmt = $conn->prepare("SELECT * FROM crops WHERE name LIKE ?");
    $stmt->execute(["%$keyword%"]);
    $results['crops'] = $stmt->fetchAll();

    // ค้นหาในตารางเซ็นเซอร์
    $stmt = $conn->prepare("SELECT * FROM sensors WHERE name LIKE ?");
    $stmt->execute(["%$keyword%"]);
    $results['sensors'] = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ผลการค้นหา - ฟาร์มอัจฉริยะ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <?php include 'navbar.php'; ?>

    <div class="container py-5">
        <h1 class="text-center">ผลการค้นหา</h1>
        <form method="GET" action="" class="mb-4">
            <div class="input-group">
                <input type="text" class="form-control" name="keyword" placeholder="ค้นหา..." required>
                <button type="submit" class="btn btn-primary">ค้นหา</button>
            </div>
        </form>

        <?php if (!empty($results)): ?>
            <!-- ผลการค้นหาสัตว์ -->
            <?php if (!empty($results['animals'])): ?>
                <h3>สัตว์</h3>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>ชื่อ</th>
                            <th>สายพันธุ์</th>
                            <th>วันเกิด</th>
                            <th>สถานะสุขภาพ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($results['animals'] as $animal): ?>
                            <tr>
                                <td><?php echo $animal['animal_id']; ?></td>
                                <td><?php echo $animal['name']; ?></td>
                                <td><?php echo $animal['species']; ?></td>
                                <td><?php echo $animal['birth_date']; ?></td>
                                <td><?php echo $animal['health_status']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <!-- ผลการค้นหาพืชผล -->
            <?php if (!empty($results['crops'])): ?>
                <h3>พืชผล</h3>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>ชื่อพืช</th>
                            <th>ประเภท</th>
                            <th>วันที่ปลูก</th>
                            <th>วันที่เก็บเกี่ยว</th>
                            <th>สถานะ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($results['crops'] as $crop): ?>
                            <tr>
                                <td><?php echo $crop['crop_id']; ?></td>
                                <td><?php echo $crop['name']; ?></td>
                                <td><?php echo $crop['type']; ?></td>
                                <td><?php echo $crop['planting_date']; ?></td>
                                <td><?php echo $crop['harvest_date']; ?></td>
                                <td><?php echo $crop['status']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <!-- ผลการค้นหาเซ็นเซอร์ -->
            <?php if (!empty($results['sensors'])): ?>
                <h3>เซ็นเซอร์</h3>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>ชื่อเซ็นเซอร์</th>
                            <th>ประเภท</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($results['sensors'] as $sensor): ?>
                            <tr>
                                <td><?php echo $sensor['sensor_id']; ?></td>
                                <td><?php echo $sensor['name']; ?></td>
                                <td><?php echo $sensor['type']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        <?php else: ?>
            <p class="text-center">ไม่พบผลลัพธ์</p>
        <?php endif; ?>
    </div>
</body>
</html>
