<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require 'config.php';

// การดึงข้อมูลพืชผลจากฐานข้อมูล
$stmt = $conn->prepare("SELECT * FROM crops");
$stmt->execute();
$crops = $stmt->fetchAll();

// การลบพืชผล
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $stmt = $conn->prepare("DELETE FROM crops WHERE crop_id = ?");
    $stmt->execute([$delete_id]);
    header("Location: crops.php"); // เมื่อลบเสร็จแล้วให้กลับไปที่หน้ารายการพืชผล
    exit();
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>พืชผล - ฟาร์มอัจฉริยะ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <?php include 'navbar.php'; ?>

    <div class="container py-5">
        <h1 class="text-center">พืชผล</h1>

        <!-- ปุ่มเพิ่มพืชผลใหม่ -->
        <div class="mb-3 text-end">
            <a href="add_crop.php" class="btn btn-success">+ เพิ่มพืชผลใหม่</a>
        </div>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>ชื่อพืช</th>
                    <th>ประเภท</th>
                    <th>วันที่ปลูก</th>
                    <th>วันที่เก็บเกี่ยว</th>
                    <th>สถานะ</th>
                    <th>การจัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($crops as $crop): ?>
                    <tr>
                        <td><?php echo $crop['crop_id']; ?></td>
                        <td><?php echo $crop['name']; ?></td>
                        <td><?php echo $crop['type']; ?></td>
                        <td><?php echo $crop['planting_date']; ?></td>
                        <td><?php echo $crop['harvest_date']; ?></td>
                        <td><?php echo $crop['status']; ?></td>
                        <td>
                            <!-- ปุ่มลบพืชผล -->
                            <a href="crops.php?delete_id=<?php echo $crop['crop_id']; ?>" class="btn btn-danger" onclick="return confirm('คุณต้องการลบข้อมูลนี้ใช่หรือไม่?');">ลบ</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
