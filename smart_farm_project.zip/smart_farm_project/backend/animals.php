<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require 'config.php';

// การดึงข้อมูลสัตว์จากฐานข้อมูล
$stmt = $conn->prepare("SELECT * FROM animals");
$stmt->execute();
$animals = $stmt->fetchAll();

// การลบสัตว์
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $stmt = $conn->prepare("DELETE FROM animals WHERE animal_id = ?");
    $stmt->execute([$delete_id]);
    header("Location: animals.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>สัตว์ - ฟาร์มอัจฉริยะ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <?php include 'navbar.php'; ?>

    <div class="container py-5">
        <h1 class="text-center">สัตว์</h1>

        <!-- ปุ่มเพิ่มสัตว์ใหม่ -->
        <div class="mb-3 text-end">
            <a href="add_animal.php" class="btn btn-success">+ เพิ่มสัตว์ใหม่</a>
        </div>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>ชื่อ</th>
                    <th>พันธุ์</th>
                    <th>วันเกิด</th>
                    <th>สถานะสุขภาพ</th>
                    <th>การจัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($animals as $animal): ?>
                    <tr>
                        <td><?php echo $animal['animal_id']; ?></td>
                        <td><?php echo $animal['name']; ?></td>
                        <td><?php echo $animal['species']; ?></td>
                        <td><?php echo $animal['birth_date']; ?></td>
                        <td>
                            <!-- ฟอร์มเลือกสถานะสุขภาพ -->
                            <form action="update_health_status.php" method="POST">
                                <input type="hidden" name="animal_id" value="<?php echo $animal['animal_id']; ?>">
                                <select name="health_status" class="form-select">
                                    <option value="แข็งแรง" <?php echo ($animal['health_status'] == 'แข็งแรง') ? 'selected' : ''; ?>>แข็งแรง</option>
                                    <option value="ป่วย" <?php echo ($animal['health_status'] == 'ป่วย') ? 'selected' : ''; ?>>ป่วย</option>
                                    <option value="กำลังรักษา" <?php echo ($animal['health_status'] == 'กำลังรักษา') ? 'selected' : ''; ?>>กำลังรักษา</option>
                                </select>
                                <button type="submit" class="btn btn-primary mt-2">อัปเดต</button>
                            </form>
                        </td>
                        <td>
                            <!-- ปุ่มลบสัตว์ -->
                            <a href="animals.php?delete_id=<?php echo $animal['animal_id']; ?>" class="btn btn-danger" onclick="return confirm('คุณต้องการลบข้อมูลนี้ใช่หรือไม่?');">ลบ</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>


