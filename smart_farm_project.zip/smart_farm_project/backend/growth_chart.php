<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require 'config.php';

// ดึงข้อมูลจำนวนสัตว์ทั้งหมดจากฐานข้อมูล
$stmt = $conn->prepare("SELECT COUNT(*) FROM animals");
$stmt->execute();
$total_animals = $stmt->fetchColumn();

// ดึงข้อมูลจำนวนพืชทั้งหมดจากฐานข้อมูล
$stmt = $conn->prepare("SELECT COUNT(*) FROM crops");
$stmt->execute();
$total_crops = $stmt->fetchColumn();
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>แผนภูมิการเจริญเติบโต - ฟาร์มอัจฉริยะ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-light">
    <?php include 'navbar.php'; ?>

    <div class="container py-5">
        <h1 class="text-center">แผนภูมิการเจริญเติบโต</h1>
        <canvas id="myChart"></canvas>
        <script>
            const ctx = document.getElementById('myChart').getContext('2d');
            const myChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['สัตว์', 'พืช'],
                    datasets: [{
                        label: 'จำนวนรวม',
                        data: [<?php echo $total_animals; ?>, <?php echo $total_crops; ?>],
                        backgroundColor: ['rgba(75, 192, 192, 0.2)', 'rgba(153, 102, 255, 0.2)'],
                        borderColor: ['rgba(75, 192, 192, 1)', 'rgba(153, 102, 255, 1)'],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        </script>
    </div>
</body>
</html>
