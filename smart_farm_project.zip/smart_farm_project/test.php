<?php
require 'config.php'; // ไฟล์เชื่อมต่อฐานข้อมูล

$username = "test_user"; // ตัวอย่างชื่อผู้ใช้
$stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
$stmt->execute([$username]);
$user = $stmt->fetch();

if ($user) {
    echo "User found: " . $user['username'];
} else {
    echo "User not found!";
}
?>